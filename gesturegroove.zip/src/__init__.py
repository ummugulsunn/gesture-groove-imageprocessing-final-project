"""
GestureGroove: Music Player with Hand Gestures
Main package file
"""
 
__version__ = "1.0.0"
__author__ = "Ayşenur, Ümmu Gülsün, Sueda" 